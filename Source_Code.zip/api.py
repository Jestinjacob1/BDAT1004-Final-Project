from flask import Flask, jsonify, request
import sqlite3
import json
from flask import Flask, jsonify, Response, request
# initialize our Flask application
app= Flask(__name__)
@app.route("/insertData", methods=["POST"])
def setName():
    if request.method=='POST':
        posted_data = request.get_json()
        crime = posted_data['crime']
        number = posted_data['number']
        con = sqlite3.connect('mydatabase.db')
        cur = con.cursor()    
        sqlite_insert_with_param = """INSERT INTO downloaded (crime,number)  VALUES (?, ?);"""
                                 
        data_tuple = (crime,number)
        cur.execute(sqlite_insert_with_param, data_tuple)
        cur.execute("SELECT * FROM downloaded where crime = ?", (crime,))
        con.commit()
        cur = cur.fetchall()
        con.close()
        return jsonify(str("Successfully stored  " + str(crime) + " and number: " + str(number)  ))
@app.route("/getCrimeByName", methods=["GET"])
def message():
    if request.method=='GET':
        posted_data = request.get_json()
        crime = posted_data['crime']
        limit = posted_data['limit']
        con = sqlite3.connect('mydatabase.db')
        cur = con.cursor()    
        cur.execute("SELECT * FROM downloaded where crime like ? limit ?", ('%'+crime+'%',limit))
        rows = cur.fetchall()
        return Response(json.dumps(rows), mimetype='application/json; charset=utf-8')
#  main thread of execution to start the server
if __name__=='__main__':
    #app.run(debug=True)
    app.run(debug=True, port=4000, host='0.0.0.0')
