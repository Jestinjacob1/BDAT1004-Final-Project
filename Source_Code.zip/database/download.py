import subprocess
import requests
import os
import sys
url = 'http://gulfapps.mobi/atlcrime.csv'
req = requests.get(url)
url_content = req.content
csv_file = open('downloaded.csv', 'wb')
csv_file.write(url_content)
os.system('sh script.sh')
