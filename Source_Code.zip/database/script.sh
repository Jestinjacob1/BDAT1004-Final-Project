#script.sh
csvs-to-sqlite /root/python2020/flask/database/downloaded.csv /root/python2020/flask/database/mydatabase
