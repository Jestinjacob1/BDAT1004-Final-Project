from flask import Flask, jsonify, render_template, url_for
from flask_charts import GoogleCharts, Chart, ChartData
from random import randint
import sqlite3

app = Flask(__name__)
charts = GoogleCharts(app)
@app.route("/Random/")
def Random():
    con = sqlite3.connect('mydatabase.db')
    cur = con.cursor()    
    cur.execute(" SELECT crime, COUNT(*) FROM downloaded GROUP BY crime ORDER BY COUNT(*) DESC")
    rows = cur.fetchall()
    charts = ["BarChart","PieChart","ColumnChart","ScatterChart"]
    
    ScatterChart = Chart(charts[3], "Crime")
    ColumnChart = Chart(charts[2], "Crime")
    PieChart = Chart(charts[1], "Crime")
    BarChart = Chart(charts[0], "Crime")
    
    options = {
                            "title": "Crime",
                            "is3D": True,
                            "width": 500,
                            "height": 500
                          }
    BarChart.options = options
    PieChart.options = options
    ColumnChart.options = options
    ScatterChart.options = options

    BarChart.data.add_column("string", "Person")
    BarChart.data.add_column("number", "Count")
    
    PieChart.data.add_column("string", "Person")
    PieChart.data.add_column("number", "Count")
    
    ColumnChart.data.add_column("string", "Person")
    ColumnChart.data.add_column("number", "Count")
    
    ScatterChart.data.add_column("string", "Person")
    ScatterChart.data.add_column("number", "Count")
    
    #pizza_chart.data.add_row(["Albin", 3])
    #pizza_chart.data.add_row(["Robert", 4])
    #pizza_chart.data.add_row(["Daniel", 2.5])
    counter = 0
    for row in rows:
        BarChart.data.add_row([row[0],row[1]])
        PieChart.data.add_row([row[0],row[1]])
        ColumnChart.data.add_row([row[0],row[1]])
        ScatterChart.data.add_row([row[0],row[1]])
 
        counter = counter + 1
    #BarChart.add_event_listener("select", "my_function")
                                                                                                                      # Refreshes every second
    random_chart = Chart("BarChart", "random_chart", options= {"title": "Random values"}, data_url=url_for("data"), refresh=1000)
     
    
    return render_template("index.html", ScatterChart=random_chart, random_chart=random_chart)
    
@app.route("/ScatterChart/")
def ScatterChart():
    con = sqlite3.connect('mydatabase.db')
    cur = con.cursor()    
    cur.execute(" SELECT crime, COUNT(*) FROM downloaded GROUP BY crime ORDER BY COUNT(*) DESC")
    rows = cur.fetchall()
    charts = ["BarChart","PieChart","ColumnChart","ScatterChart"]
    
    ScatterChart = Chart(charts[3], "Crime")
    ColumnChart = Chart(charts[2], "Crime")
    PieChart = Chart(charts[1], "Crime")
    BarChart = Chart(charts[0], "Crime")
    
    options = {
                            "title": "Crime",
                            "is3D": True,
                            "width": 500,
                            "height": 500
                          }
    BarChart.options = options
    PieChart.options = options
    ColumnChart.options = options
    ScatterChart.options = options

    BarChart.data.add_column("string", "Person")
    BarChart.data.add_column("number", "Count")
    
    PieChart.data.add_column("string", "Person")
    PieChart.data.add_column("number", "Count")
    
    ColumnChart.data.add_column("string", "Person")
    ColumnChart.data.add_column("number", "Count")
    
    ScatterChart.data.add_column("string", "Person")
    ScatterChart.data.add_column("number", "Count")
    
    #pizza_chart.data.add_row(["Albin", 3])
    #pizza_chart.data.add_row(["Robert", 4])
    #pizza_chart.data.add_row(["Daniel", 2.5])
    counter = 0
    for row in rows:
        BarChart.data.add_row([row[0],row[1]])
        PieChart.data.add_row([row[0],row[1]])
        ColumnChart.data.add_row([row[0],row[1]])
        ScatterChart.data.add_row([row[0],row[1]])
       # print(str(row[2]) )
        counter = counter + 1
    #BarChart.add_event_listener("select", "my_function")
                                                                                                                      # Refreshes every second
    random_chart = Chart("BarChart", "random_chart", options= {"title": "Random values"}, data_url=url_for("data"), refresh=1000)
     
    
    return render_template("index.html", ScatterChart=ScatterChart, random_chart=random_chart)
    
    

@app.route("/ColumnChart/")
def ColumnChart():
    con = sqlite3.connect('mydatabase.db')
    cur = con.cursor()    
    cur.execute(" SELECT crime, COUNT(*) FROM downloaded GROUP BY crime ORDER BY COUNT(*) DESC")
    rows = cur.fetchall()
    charts = ["BarChart","PieChart","ColumnChart","ScatterChart"]
    
    ScatterChart = Chart(charts[3], "Crime")
    ColumnChart = Chart(charts[2], "Crime")
    PieChart = Chart(charts[1], "Crime")
    BarChart = Chart(charts[0], "Crime")
    
    options = {
                            "title": "Crime",
                            "is3D": True,
                            "width": 500,
                            "height": 500
                          }
    BarChart.options = options
    PieChart.options = options
    ColumnChart.options = options
    ScatterChart.options = options

    BarChart.data.add_column("string", "Person")
    BarChart.data.add_column("number", "Count")
    
    PieChart.data.add_column("string", "Person")
    PieChart.data.add_column("number", "Count")
    
    ColumnChart.data.add_column("string", "Person")
    ColumnChart.data.add_column("number", "Count")
    
    ScatterChart.data.add_column("string", "Person")
    ScatterChart.data.add_column("number", "Count")
    
     
    counter = 0
    for row in rows:
        BarChart.data.add_row([row[0],row[1]])
        PieChart.data.add_row([row[0],row[1]])
        ColumnChart.data.add_row([row[0],row[1]])
        ScatterChart.data.add_row([row[0],row[1]])
        counter = counter + 1
    #BarChart.add_event_listener("select", "my_function")
                                                                                                                      # Refreshes every second
    random_chart = Chart("BarChart", "random_chart", options= {"title": "Random values"}, data_url=url_for("data"), refresh=1000)
     
    
    return render_template("index.html", ScatterChart=ColumnChart, random_chart=random_chart)
    
@app.route("/PieChart/")
def PieChart():
    con = sqlite3.connect('mydatabase.db')
    cur = con.cursor()    
    cur.execute(" SELECT crime, COUNT(*) FROM downloaded GROUP BY crime ORDER BY COUNT(*) DESC")
    rows = cur.fetchall()
    charts = ["BarChart","PieChart","ColumnChart","ScatterChart"]
    
    ScatterChart = Chart(charts[3], "Crime")
    ColumnChart = Chart(charts[2], "Crime")
    PieChart = Chart(charts[1], "Crime")
    BarChart = Chart(charts[0], "Crime")
    
    options = {
                            "title": "Crime",
                            "is3D": True,
                            "width": 500,
                            "height": 500
                          }
    BarChart.options = options
    PieChart.options = options
    ColumnChart.options = options
    ScatterChart.options = options

    BarChart.data.add_column("string", "Person")
    BarChart.data.add_column("number", "Count")
    
    PieChart.data.add_column("string", "Person")
    PieChart.data.add_column("number", "Count")
    
    ColumnChart.data.add_column("string", "Person")
    ColumnChart.data.add_column("number", "Count")
    
    ScatterChart.data.add_column("string", "Person")
    ScatterChart.data.add_column("number", "Count")
    
 
    counter = 0
    for row in rows:
        BarChart.data.add_row([row[0],row[1]])
        PieChart.data.add_row([row[0],row[1]])
        ColumnChart.data.add_row([row[0],row[1]])
        ScatterChart.data.add_row([row[0],row[1]])
  
        counter = counter + 1
    #BarChart.add_event_listener("select", "my_function")
                                                                                                                      # Refreshes every second
    random_chart = Chart("BarChart", "random_chart", options= {"title": "Random values"}, data_url=url_for("data"), refresh=1000)
     
    
    return render_template("index.html", ScatterChart=PieChart, random_chart=random_chart)
    
    
@app.route("/BarChart/")
def BarChart():
    con = sqlite3.connect('mydatabase.db')
    cur = con.cursor()    
    cur.execute(" SELECT crime, COUNT(*) FROM downloaded GROUP BY crime ORDER BY COUNT(*) DESC")
    rows = cur.fetchall()
    charts = ["BarChart","PieChart","ColumnChart","ScatterChart"]
    
    ScatterChart = Chart(charts[3], "Crime")
    ColumnChart = Chart(charts[2], "Crime")
    PieChart = Chart(charts[1], "Crime")
    BarChart = Chart(charts[0], "Crime")
    
    options = {
                            "title": "Crime",
                            "is3D": True,
                            "width": 500,
                            "height": 500
                          }
    BarChart.options = options
    PieChart.options = options
    ColumnChart.options = options
    ScatterChart.options = options

    BarChart.data.add_column("string", "Person")
    BarChart.data.add_column("number", "Count")
    
    PieChart.data.add_column("string", "Person")
    PieChart.data.add_column("number", "Count")
    
    ColumnChart.data.add_column("string", "Person")
    ColumnChart.data.add_column("number", "Count")
    
    ScatterChart.data.add_column("string", "Person")
    ScatterChart.data.add_column("number", "Count")
    
 
    counter = 0
    for row in rows:
        BarChart.data.add_row([row[0],row[1]])
        PieChart.data.add_row([row[0],row[1]])
        ColumnChart.data.add_row([row[0],row[1]])
        ScatterChart.data.add_row([row[0],row[1]])
         
        counter = counter + 1
    #BarChart.add_event_listener("select", "my_function")
                                                                                                                      # Refreshes every second
    random_chart = Chart("BarChart", "random_chart", options= {"title": "Random values"}, data_url=url_for("data"), refresh=1000)
     
    
    return render_template("index.html", ScatterChart=BarChart, random_chart=random_chart)
    
    
@app.route("/")
def index():
    con = sqlite3.connect('mydatabase.db')
    cur = con.cursor()    
    cur.execute(" SELECT crime, COUNT(*) FROM downloaded GROUP BY crime ORDER BY COUNT(*) DESC")
    rows = cur.fetchall()
    charts = ["BarChart","PieChart","ColumnChart","ScatterChart"]
    
    ScatterChart = Chart(charts[3], "Crime")
    ColumnChart = Chart(charts[2], "Crime")
    PieChart = Chart(charts[1], "Crime")
    BarChart = Chart(charts[0], "Crime")
    
    options = {
                            "title": "Crime",
                            "is3D": True,
                            "width": 500,
                            "height": 500
                          }
    BarChart.options = options
    PieChart.options = options
    ColumnChart.options = options
    ScatterChart.options = options

    BarChart.data.add_column("string", "Person")
    BarChart.data.add_column("number", "Count")
    
    PieChart.data.add_column("string", "Person")
    PieChart.data.add_column("number", "Count")
    
    ColumnChart.data.add_column("string", "Person")
    ColumnChart.data.add_column("number", "Count")
    
    ScatterChart.data.add_column("string", "Person")
    ScatterChart.data.add_column("number", "Count")
    
 
    counter = 0
    for row in rows:
        BarChart.data.add_row([row[0],row[1]])
        PieChart.data.add_row([row[0],row[1]])
        ColumnChart.data.add_row([row[0],row[1]])
        ScatterChart.data.add_row([row[0],row[1]])
 
        counter = counter + 1
    #BarChart.add_event_listener("select", "my_function")
                                                                                                                      # Refreshes every second
    random_chart = Chart("BarChart", "random_chart", options= {"title": "Random values"}, data_url=url_for("data"), refresh=1000)
     
    
    return render_template("index.html", ScatterChart=ScatterChart,BarChart=BarChart, random_chart=random_chart)

@app.route("/data", methods=["POST"])
def data():
    data = ChartData()
    data.add_column("string", "Person")
    data.add_column("number", "Count")

    data.add_row(["Mohammad", randint(1, 100)])
    data.add_row(["Yemini", randint(1, 100)])
    data.add_row(["Jestin", randint(1, 100)])

    return jsonify(data.data())


if __name__ == "__main__":

    #app.run(debug=True)
    #charts = GoogleCharts()
    #charts.init_app(app)
    app.run(debug=True, port=3000, host='0.0.0.0')
